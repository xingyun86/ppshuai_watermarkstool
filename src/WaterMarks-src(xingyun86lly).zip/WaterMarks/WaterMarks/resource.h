//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by WaterMarks.rc
//
#define IDS_PROJNAME                    100
#define IDR_WATERMARKS                  100
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDD_MAINDLG                     129
#define IDC_STATIC_BACKGROUND           1000
#define IDC_STATIC_TEXTFONT             1002
#define IDC_STATIC_FONTNAME             1003
#define IDC_STATIC_FONTSIZE             1004
#define IDC_EDIT_FONTSIZE               1005
#define IDC_COMBO_FONTNAME              1006
#define IDC_STATIC_FONTCOLOR            1007
#define IDC_BUTTON_FONTCOLOR            1008
#define IDC_STATIC_FONTSTOKE            1009
#define IDC_COMBO_FONTSTOKE             1010
#define IDC_STATIC_OPENFILE             1011
#define IDC_EDIT_OPENFILE               1012
#define IDC_BUTTON_OPENFILE             1013
#define IDC_STATIC_OPERATOR             1014
#define IDC_BUTTON_MAKEFILE             1015
#define IDC_BUTTON_APPLYCONFIG          1016
#define IDC_COMBO_FONTSTYLE             1017
#define IDC_SPIN_FONTSIZE               1018
#define IDC_CHECK_UNDERLINE             1019
#define IDC_CHECK_STRIKEOUT             1020
#define IDC_STATIC_ABOUT                1021

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        204
#define _APS_NEXT_COMMAND_VALUE         32775
#define _APS_NEXT_CONTROL_VALUE         1022
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
