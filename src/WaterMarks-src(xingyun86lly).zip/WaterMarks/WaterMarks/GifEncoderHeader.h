#pragma once

#include "stdafx.h"

//================================================================================
/// @brief ��̬Gifͼ��ı���
///
/// ͨ����̬���Ӷ��ͼ����ϲ���Gif����ͼ��
//================================================================================
class CGifEncoder
{
public:
	CGifEncoder()
	{
		m_started = false;
		m_width = 320;
		m_height = 240;
		m_delayTime = 100;
		m_repeatNum = 0;
		m_haveFrame = false;
		m_pStrSavePath = NULL;
		m_pImage = NULL;
	}

	~CGifEncoder()
	{
		if (NULL != m_pStrSavePath)
		{
			delete m_pStrSavePath;
		}

		if (NULL != m_pImage)
		{
			delete m_pImage;
		}

		size_t size = m_pBitMapVec.size();
		for (size_t ix = 0; ix<size; ix++)
		{
			delete m_pBitMapVec[ix];
			m_pBitMapVec[ix] = NULL;
		}
	}

public:
	//=================================StartEncoder()=================================
	/// @brief ��ʼgif����
	///
	/// @param [in] saveFilePath gifͼ�񱣴��ȫ·��
	///
	/// @return �ɹ�����true
	//================================================================================
	bool StartEncoder(std::wstring &saveFilePath)
	{
		bool flag = true;

		if (NULL != m_pStrSavePath)
		{
			delete m_pStrSavePath;
			m_pStrSavePath = NULL;
		}

		m_pStrSavePath = new std::wstring(saveFilePath);
		m_started = true;

		return(flag);
	}

	//===================================AddFrame()===================================
	/// @brief ����ͼ��
	///
	/// @param [in] im  Image����
	///
	/// @return �ɹ�����true
	//================================================================================

	bool AddFrame(Gdiplus::Image *pImage)
	{
		if (!m_started || NULL == pImage)
		{
			return(false);
		}

		bool flag = true;
		if (!m_haveFrame)
		{
			m_pImage = new Gdiplus::Bitmap(m_width, m_height);
			Gdiplus::Graphics g(m_pImage);
			g.SetSmoothingMode(Gdiplus::SmoothingModeNone);
			g.SetInterpolationMode(Gdiplus::InterpolationModeHighQualityBicubic);
			g.DrawImage(pImage, 0, 0, m_width, m_height);

			m_haveFrame = true;
			return(true);
		}

		Gdiplus::Bitmap *pBitMap = new Gdiplus::Bitmap(m_width, m_height);
		Gdiplus::Graphics g(pBitMap);
		g.SetSmoothingMode(Gdiplus::SmoothingModeNone);
		g.SetInterpolationMode(Gdiplus::InterpolationModeHighQualityBicubic);
		g.DrawImage(pImage, 0, 0, m_width, m_height);
		m_pBitMapVec.push_back(pBitMap);

		return(flag);
	}
	//===================================AddFrame()===================================
	/// @brief ����ͼ��
	///
	/// @param [in] framePath ͼ���ȫ·��
	///
	/// @return  �ɹ�����true
	//================================================================================
	bool CGifEncoder::AddFrame(std::wstring &framePath)
	{
		if (!m_started)
		{
			return(false);
		}

		bool flag = true;
		Gdiplus::Status statue;
		if (!m_haveFrame)
		{
			m_pImage = new Gdiplus::Bitmap(m_width, m_height);
			Gdiplus::Graphics g(m_pImage);

			Gdiplus::Bitmap bitmap(framePath.c_str());
			g.SetSmoothingMode(Gdiplus::SmoothingModeNone);
			g.SetInterpolationMode(Gdiplus::InterpolationModeHighQualityBicubic);
			g.DrawImage(&bitmap, 0, 0, m_width, m_height);

			m_haveFrame = true;
			return(true);
		}

		Gdiplus::Bitmap		*pBitMap = new Gdiplus::Bitmap(m_width, m_height);
		Gdiplus::Graphics	g(pBitMap);

		Gdiplus::Bitmap bitmap(framePath.c_str());
		g.SetSmoothingMode(Gdiplus::SmoothingModeNone);
		g.SetInterpolationMode(Gdiplus::InterpolationModeHighQualityBicubic);
		statue = g.DrawImage(&bitmap, 0, 0, m_width, m_height);

		m_pBitMapVec.push_back(pBitMap);

		return(flag);
	}
	//================================FinishEncoder()===============================
	/// @brief ����gif�ı���
	///
	/// @return  �ɹ�����true
	//================================================================================
	bool FinishEncoder()
	{
		if (!m_started || !m_haveFrame)
		{
			return(false);
		}

		bool	flag = true;
		Gdiplus::Status statue;

		//1.0 ����ͼ�������
		SetImagePropertyItem();

		//2.0 �����һ��ͼ��
		GUID						gifGUID;
		Gdiplus::EncoderParameters	encoderParams;
		GetEncoderClsid(L"image/gif", &gifGUID);

		encoderParams.Count = 1;
		encoderParams.Parameter[0].Guid = Gdiplus::EncoderSaveFlag;
		encoderParams.Parameter[0].NumberOfValues = 1;
		encoderParams.Parameter[0].Type = Gdiplus::EncoderParameterValueTypeLong;//��һ֡��Ҫ����ΪMultiFrame

		long firstValue = Gdiplus::EncoderValueMultiFrame;
		encoderParams.Parameter[0].Value = &firstValue;

		m_pImage->Save(m_pStrSavePath->c_str(), &gifGUID, &encoderParams);

		//3.0 ����ʣ���ͼ��
		size_t size = m_pBitMapVec.size();
		firstValue = Gdiplus::EncoderValueFrameDimensionTime;
		encoderParams.Parameter[0].Value = &firstValue;
		for (size_t ix = 0; ix <size; ix++)
		{
			statue = m_pImage->SaveAdd(m_pBitMapVec[ix], &encoderParams);
		}

		m_started = false;
		m_haveFrame = false;
		return(flag);
	}
	//=================================SetDelayTime()=================================
	/// @brief ��������ͼ���л���ʱ����
	///
	/// @param [in] ms ʱ��,�Ժ���Ϊ��λ
	///
	/// @return ��
	//================================================================================
	void SetDelayTime(int ms)
	{
		if (ms > 0)
		{
			m_delayTime = ms / 10.0f;
		}
	}
	//=================================SetRepeatNum()=================================
	/// @brief ����gif�������ŵĴ���
	///
	/// @param [in] num ������0��ʾ���޴�
	///
	/// @return ��
	//================================================================================
	void SetRepeatNum(int num)
	{
		if (num >= 0)
		{
			m_repeatNum = num;
		}
	}
	//=================================SetFrameRate()=================================
	/// @brief ����ͼ���֡��
	///
	/// @param [in] fps ֡�ʣ�ÿ�벥��ͼ�����Ŀ
	///
	/// @return ��
	//================================================================================
	void SetFrameRate(float fps)
	{
		if (fps > 0)
		{
			m_delayTime = 100.0f / fps;
		}
	}
	//=================================SetFrameSize()=================================
	/// @brief ����ͼ��ĳߴ�
	///
	/// @param [in] width  ͼ��Ŀ���
	/// @param [in] height ͼ��ĸ߶�
	///
	/// @return ��
	//================================================================================
	void SetFrameSize(int width, int height)
	{
		if (!m_haveFrame)
		{
			m_width = width;
			m_height = height;

			if (m_width < 1)
				m_width = 320;

			if (m_height < 1)
				height = 240;
		}
	}

private:
	void SetImagePropertyItem()
	{
		if (!m_started || NULL == m_pImage)
		{
			return;
		}

		Gdiplus::PropertyItem propertyItem;

		//1.0 ���ö���ѭ���Ĵ���	
		short sValue = m_repeatNum; //0 -- ���޴���
		propertyItem.id = PropertyTagLoopCount;
		propertyItem.length = 2; //�ֽ���
		propertyItem.type = PropertyTagTypeShort;
		propertyItem.value = &sValue;
		m_pImage->SetPropertyItem(&propertyItem);

		//2.0 ����ÿ��ͼ���ӳٵ�ʱ�䣬�ӵ�һ����ʼ
		long lImageNum = 1 + m_pBitMapVec.size();
		long *plValue = new long[lImageNum];
		for (int ix = 0; ix<lImageNum; ix++)
		{
			plValue[ix] = m_delayTime; //�������ò�һ��
		}
		propertyItem.id = PropertyTagFrameDelay;
		propertyItem.length = 4 * lImageNum;//�ֽ���
		propertyItem.type = PropertyTagTypeLong;
		propertyItem.value = plValue; //���޴���
		m_pImage->SetPropertyItem(&propertyItem);

		delete[]plValue;
		plValue = NULL;
	}

	bool GetEncoderClsid(const WCHAR* format, CLSID* pClsid)
	{
		UINT num = 0, size = 0;

		Gdiplus::GetImageEncodersSize(&num, &size);
		if (size == 0)
			return false;  // Failure

		Gdiplus::ImageCodecInfo* pImageCodecInfo = (Gdiplus::ImageCodecInfo*)(malloc(size));

		Gdiplus::GetImageEncoders(num, size, pImageCodecInfo);
		bool found = false;
		for (UINT ix = 0; !found && ix < num; ++ix)
		{
			if (_wcsicmp(pImageCodecInfo[ix].MimeType, format) == 0)
			{
				*pClsid = pImageCodecInfo[ix].Clsid;
				found = true;
				break;
			}
		}

		free(pImageCodecInfo);
		return found;
	}

private:
	int					m_width;
	int					m_height;
	int					m_repeatNum;
	int					m_delayTime;
	bool				m_started;
	bool				m_haveFrame;

	std::wstring				*m_pStrSavePath;
	Gdiplus::Bitmap		*m_pImage;
	std::vector<Gdiplus::Bitmap *> m_pBitMapVec;
};