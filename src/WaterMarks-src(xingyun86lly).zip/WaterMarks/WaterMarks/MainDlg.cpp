// MainDlg.cpp : implementation of the CMainDlg class
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "resource.h"
#include "aboutdlg.h"
#include "MainDlg.h"

BOOL CMainDlg::PreTranslateMessage(MSG* pMsg)
{
	return CWindow::IsDialogMessage(pMsg);
}

BOOL CMainDlg::OnIdle()
{
	UIUpdateChildWindows();
	return FALSE;
}

LRESULT CMainDlg::OnEraseBkGnd(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
{
	return TRUE;
}
void CMainDlg::PaintBackground(HDC hDC)
{
	RECT rect = { 0 };
	//BLENDFUNCTION bf = { 0 };

	////����AlphaBind�����һ������
	//bf.BlendOp = AC_SRC_OVER;
	//bf.BlendFlags = 0;
	//bf.SourceConstantAlpha = 255;
	//bf.AlphaFormat = AC_SRC_ALPHA;
	
	GetClientRect(&rect);
	Gdiplus::Graphics graphicsM(hDC);
	graphicsM.SetSmoothingMode(Gdiplus::SmoothingModeNone);
	graphicsM.SetInterpolationMode(Gdiplus::InterpolationModeHighQualityBicubic);
	//graphicsM.FillRectangle(&Gdiplus::SolidBrush(Gdiplus::Color::LightPink), rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top);
	graphicsM.FillRectangle(&Gdiplus::SolidBrush(Gdiplus::Color::WhiteSmoke), rect.left, rect.top, rect.right - rect.left, 30);
	graphicsM.ReleaseHDC(hDC);

	GetDlgItem(IDC_STATIC_BACKGROUND).GetClientRect(&rect);
	GetDlgItem(IDC_STATIC_BACKGROUND).MapWindowPoints(m_hWnd, &rect);
	//m_pGraphics->DrawImage(m_pImage, rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top);
	//::AlphaBlend(hDC, rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top, m_mb_org.hMDC, rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top, bf);
	::BitBlt(hDC, rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top, m_mb_org.hMDC, rect.left, rect.top, SRCCOPY);
}

void CMainDlg::PaintBackgroundReality(HDC hDC, Gdiplus::Image * pImage)
{
	Gdiplus::Graphics graphics(hDC);
	graphics.SetSmoothingMode(Gdiplus::SmoothingModeNone);
	graphics.SetInterpolationMode(Gdiplus::InterpolationModeHighQualityBicubic);
	graphics.DrawImage(pImage, 0, 0);
}
void CMainDlg::DrawColorButton(HDC hDC)
{
	RECT rectButton = { 0 };
	((CButton)GetDlgItem(IDC_BUTTON_FONTCOLOR)).GetClientRect(&rectButton);
	((CButton)GetDlgItem(IDC_BUTTON_FONTCOLOR)).MapWindowPoints(m_hWnd, &rectButton);
	Gdiplus::Graphics graphics(m_mb_org.hMDC);
	Gdiplus::SolidBrush solidbrush(Gdiplus::Color(GetRValue(m_clrFontColor), GetGValue(m_clrFontColor), GetBValue(m_clrFontColor)));
	graphics.FillRectangle(&solidbrush, (Gdiplus::REAL)rectButton.left, (Gdiplus::REAL)rectButton.top,
		(Gdiplus::REAL)(rectButton.right - rectButton.left), (Gdiplus::REAL)(rectButton.bottom - rectButton.top));
	graphics.ReleaseHDC(m_mb_org.hMDC);
	::BitBlt(hDC, rectButton.left, rectButton.top, rectButton.right - rectButton.left, rectButton.bottom - rectButton.top, m_mb_org.hMDC, rectButton.left, rectButton.top, SRCCOPY);
}

LRESULT CMainDlg::OnPaint(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
{
	PAINTSTRUCT ps = { 0 };
	
	HDC hDC = BeginPaint(&ps);

	PaintBackground(hDC);
	
	DrawColorButton(hDC);

	if (!m_bRecoveryOriginal)
	{
		DrawMarkText(hDC, m_nVectorIndex);
	}

	EndPaint(&ps);

	return 0;
}

//CMD.EXE����
#define CMD_PATH_NAME				"CMD.EXE" 

__inline static //��ȡϵͳ·��
std::string GetSystemPath()
{
	std::string strSystemPath = ("");
	CHAR czSystemPath[MAX_PATH] = { 0 };
	::GetSystemDirectoryA(czSystemPath, MAX_PATH);
	if (*czSystemPath)
	{
		strSystemPath = std::string(czSystemPath) + ("\\");
	}
	return strSystemPath;
}

__inline static //��ȡϵͳ·��
std::string GetSystemPathX64()
{
	std::string strSystemPath = ("");
	CHAR czSystemPath[MAX_PATH] = { 0 };
	::GetSystemWow64DirectoryA(czSystemPath, MAX_PATH);
	if (*czSystemPath)
	{
		strSystemPath = std::string(czSystemPath) + ("\\");
	}
	return strSystemPath;
}
__inline static //��ȡcmd.exe�ļ�·��
std::string GetCmdPath()
{
	return GetSystemPath() + (CMD_PATH_NAME);
}

void MakePath(const char * pDirName, const char * pBasePath)
{
	char czCmd[MAX_PATH * sizeof(LONG)] = ("/C MKDIR \"");
	lstrcpynA(czCmd + lstrlenA(czCmd), pBasePath, lstrlenA(pBasePath) - (!(bool)(*(pBasePath + lstrlenA(pBasePath) - sizeof(CHAR)) != ('\\'))) + sizeof(CHAR));
	lstrcpyA(czCmd + lstrlenA(czCmd), "\\");
	lstrcpynA(czCmd + lstrlenA(czCmd), pDirName, lstrlenA(pDirName) - (!(bool)(*(pDirName + lstrlenA(pDirName) - sizeof(CHAR)) != ('\\'))) + sizeof(CHAR));
	lstrcpyA(czCmd + lstrlenA(czCmd), "\"");
	//system(czCmd);
	//_pclose(_popen(czCmd, "wb"));
	STARTUPINFOA sia = { 0 };
	PROCESS_INFORMATION pi = { 0 };
	sia.cb = sizeof(sia);
	if (::CreateProcessA(GetCmdPath().c_str(), czCmd, NULL, NULL, FALSE, CREATE_NO_WINDOW, NULL, NULL, &sia, &pi))
	{
		::WaitForSingleObject(pi.hProcess, INFINITE);
		::CloseHandle(pi.hProcess);
		::CloseHandle(pi.hThread);
	}
}
//#include <dwmapi.h> 
//#pragma comment(lib , "dwmapi.lib")
LRESULT CMainDlg::OnInitDialog(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
{
	//BOOL bDwm;
	//DwmIsCompositionEnabled(&bDwm);
	//if (bDwm)
	{
		//MARGINS mrg = { -1 };
		//DwmExtendFrameIntoClientArea(m_hWnd, &mrg);
		//SetBackgroundColor(RGB(0, 0, 0));
	}

	// center the dialog on the screen
	CenterWindow();

	// set icons
	HICON hIcon = AtlLoadIconImage(IDR_MAINFRAME, LR_DEFAULTCOLOR, ::GetSystemMetrics(SM_CXICON), ::GetSystemMetrics(SM_CYICON));
	SetIcon(hIcon, TRUE);
	HICON hIconSmall = AtlLoadIconImage(IDR_MAINFRAME, LR_DEFAULTCOLOR, ::GetSystemMetrics(SM_CXSMICON), ::GetSystemMetrics(SM_CYSMICON));
	SetIcon(hIconSmall, FALSE);

	// register object for message filtering and idle updates
	CMessageLoop* pLoop = _Module.GetMessageLoop();
	ATLASSERT(pLoop != NULL);
	pLoop->AddMessageFilter(this);
	pLoop->AddIdleHandler(this);

	UIAddChildWindowContainer(m_hWnd);

	GetDlgItem(IDC_STATIC_BACKGROUND).SetWindowLong(GWL_STYLE, WS_CHILD | WS_VISIBLE | SS_OWNERDRAW);
	GetDlgItem(IDC_BUTTON_FONTCOLOR).SetWindowLong(GWL_STYLE, WS_CHILD | WS_VISIBLE | SS_NOTIFY | SS_OWNERDRAW);
	((CUpDownCtrl)GetDlgItem(IDC_SPIN_FONTSIZE)).SetBuddy(GetDlgItem(IDC_EDIT_FONTSIZE));
	((CUpDownCtrl)GetDlgItem(IDC_SPIN_FONTSIZE)).SetRange(1, 500);
	((CUpDownCtrl)GetDlgItem(IDC_SPIN_FONTSIZE)).SetBase(1);
	
	//RECT rectWorkArea;
	//SystemParametersInfo(SPI_GETWORKAREA, 0, &rectWorkArea, SPIF_SENDCHANGE);//��ȡ��Ļ�ͻ�����С
	//this->MoveWindow(&rectWorkArea);
	//RECT rectBackGround = { 0, 30, rectWorkArea.right, rectWorkArea.bottom };
	//GetDlgItem(IDC_STATIC_BACKGROUND).MoveWindow(&rectBackGround);

	CHAR czFilePath[MAX_PATH] = { 0 };
	::GetModuleFileNameA(NULL, czFilePath, _countof(czFilePath));
	*(strrchr(czFilePath, '\\') + sizeof(CHAR)) = '\0';
	MakePath("src", czFilePath);
	MakePath("tmp", czFilePath);
	MakePath("out", czFilePath);

	{
		CComboBox comboBox = GetDlgItem(IDC_COMBO_FONTNAME);
		////�оٱ�����������
		//::EnumFontFamilies(GetDC(), (LPTSTR)NULL, (FONTENUMPROC)([](CONST LOGFONT *pLogFont, CONST TEXTMETRIC* /*pTextMetric*/, DWORD /*dwFontType*/, LPARAM lParam)->int {
		///	((CComboBox*)lParam)->InsertString(((CComboBox*)lParam)->GetCount(), pLogFont->lfFaceName);
		//	return TRUE;
		//}), (LPARAM)&(comboBox));

		//GDI+ö������
		EnumFontFamily(&comboBox);	
		//comboBox.SetCurSel(0);
	}
	{
		CComboBox comboBox = GetDlgItem(IDC_COMBO_FONTSTYLE);
		comboBox.InsertString(comboBox.GetCount(), _T("����"));
		comboBox.InsertString(comboBox.GetCount(), _T("�Ӵ�"));
		comboBox.InsertString(comboBox.GetCount(), _T("��б"));
		comboBox.InsertString(comboBox.GetCount(), _T("�Ӵ���б"));
		comboBox.SetCurSel(0);
	}
	{
		CComboBox comboBox = GetDlgItem(IDC_COMBO_FONTSTOKE);
		comboBox.InsertString(comboBox.GetCount(), _T("�������ʽ"));
		comboBox.InsertString(comboBox.GetCount(), _T("�ڵװױ���ʽ"));
		comboBox.InsertString(comboBox.GetCount(), _T("�׵׺ڱ���ʽ"));
		comboBox.InsertString(comboBox.GetCount(), _T("�����ʽ1"));
		comboBox.InsertString(comboBox.GetCount(), _T("�����ʽ2"));
		comboBox.InsertString(comboBox.GetCount(), _T("�����ʽ3"));
		comboBox.InsertString(comboBox.GetCount(), _T("�����ʽ4"));
		comboBox.InsertString(comboBox.GetCount(), _T("�����ʽ5"));
		comboBox.InsertString(comboBox.GetCount(), _T("�����ʽ6"));
		comboBox.SetCurSel(0);
	}
	{
		//SetWindowText(_T("����ר�������Ӻ�׺"));
		SetWindowText(_T("������ˮӡ����GIF���� v1.0(xingyun86)"));
		//GetDlgItem(IDC_STATIC_OPERATOR).SetWindowText(_T("�û�����"));
		GetDlgItem(IDC_STATIC_OPERATOR).SetWindowText(_T(""));
		//GetDlgItem(IDC_STATIC_TEXTFONT).SetWindowText(_T("��������"));
		GetDlgItem(IDC_STATIC_TEXTFONT).SetWindowText(_T(""));
		GetDlgItem(IDC_STATIC_FONTNAME).SetWindowText(_T("����:"));
		GetDlgItem(IDC_STATIC_FONTSIZE).SetWindowText(_T("�����С:"));
		GetDlgItem(IDC_EDIT_FONTSIZE).SetWindowText(_T("28"));
		GetDlgItem(IDC_STATIC_FONTCOLOR).SetWindowText(_T("������ɫ:"));
		GetDlgItem(IDC_BUTTON_FONTCOLOR).SetWindowText(_T(""));
		GetDlgItem(IDC_STATIC_FONTSTOKE).SetWindowText(_T("�������:"));
		GetDlgItem(IDC_STATIC_OPENFILE).SetWindowText(_T("���ļ�"));
		GetDlgItem(IDC_BUTTON_OPENFILE).SetWindowText(_T("���ļ�(&O)"));
		GetDlgItem(IDC_BUTTON_MAKEFILE).SetWindowText(_T("����GIF(&M)"));
		GetDlgItem(IDC_BUTTON_APPLYCONFIG).SetWindowText(_T("Ӧ������(&Y)"));
		GetDlgItem(IDCANCEL).SetWindowText(_T("�ر�����(&Q)"));
		GetDlgItem(ID_APP_ABOUT).SetWindowText(_T("��������(&A)"));
		GetDlgItem(IDC_CHECK_UNDERLINE).SetWindowText(_T("�����»���"));
		GetDlgItem(IDC_CHECK_STRIKEOUT).SetWindowText(_T("����ɾ����"));
	}
	InitMemoryBuffer(m_hWnd, m_mb_org);
	
	m_bCaptureWindows = false;
	m_bRecoveryOriginal = false;
	m_fFontSize = 28.0f;
	m_fontStyle = Gdiplus::FontStyle::FontStyleRegular;
	m_fstype = FSTYPE_NULL;
	m_nVectorIndex = 0;
	
	RECT rect = { 0 };
	GetDlgItem(IDC_STATIC_BACKGROUND).GetClientRect(&rect);
	GetDlgItem(IDC_STATIC_BACKGROUND).MapWindowPoints(m_hWnd, &rect);

	m_clrFontColor = RGB(255, 0, 0);
	lstrcpy(m_tzBkImgName, _T(""));
	lstrcpy(m_tzFileName, _T(""));
	lstrcpy(m_tzFontName, _T(USAGE_FONT));
	//������������
	((CComboBox)GetDlgItem(IDC_COMBO_FONTNAME)).GetLBText(((CComboBox)GetDlgItem(IDC_COMBO_FONTNAME)).GetCurSel(), m_tzFontName);

	m_szImage.cx = 0;
	m_szImage.cy = 0;
	m_nScaleValue = 1;
	if (*m_tzBkImgName)
	{
		//���Ʊ���
		Gdiplus::Image image(m_tzBkImgName);
		Gdiplus::Graphics graphics(m_mb_org.hMDC);
		graphics.SetSmoothingMode(Gdiplus::SmoothingModeNone);
		graphics.SetInterpolationMode(Gdiplus::InterpolationModeHighQualityBicubic);
		//graphics.SetInterpolationMode(Gdiplus::InterpolationModeNearestNeighbor);
		int nWold = rect.right - rect.left;
		int nHold = rect.bottom - rect.top;
		m_szImage.cx = image.GetWidth();
		m_szImage.cy = image.GetHeight();
		m_nScaleValue = 1;
		if (m_szImage.cx > nWold || m_szImage.cy > nHold)
		{
			while (m_nScaleValue++)
			{
				if (m_szImage.cx <= (nWold * m_nScaleValue) && m_szImage.cy <= (nHold * m_nScaleValue))
				{
					break;
				}
			}
		}
		//graphics.DrawImage(&image, Gdiplus::RectF(rect.left, rect.top, m_szImage.cx / m_nScaleValue, m_szImage.cy / m_nScaleValue), 0, 0, image.GetWidth(), image.GetHeight(), Gdiplus::UnitPixel);
		graphics.DrawImage(&image, rect.left, rect.top, m_szImage.cx / m_nScaleValue, m_szImage.cy / m_nScaleValue);
		graphics.ReleaseHDC(m_mb_org.hMDC);

		Invalidate();
		UpdateWindow();
	}

	//��ʼ�ߴ�
	m_pt_now.x = rect.left + sizeof(LONG);
	m_pt_now.y = rect.top + sizeof(LONG);

	((CUpDownCtrl)GetDlgItem(IDC_SPIN_FONTSIZE)).SetPos(m_fFontSize);
	
	/*CGifEncoder gifEncoder;
	gifEncoder.SetFrameSize(200, 200);
	gifEncoder.SetDelayTime(500);
	gifEncoder.StartEncoder(std::wstring(L"D:\\1.gif"));
	gifEncoder.AddFrame(std::wstring(L"D:\\test\\1.png"));
	gifEncoder.AddFrame(std::wstring(L"D:\\test\\2.jpg"));
	gifEncoder.AddFrame(std::wstring(L"D:\\test\\3.jpg"));
	gifEncoder.AddFrame(std::wstring(L"D:\\test\\4.jpg"));
	gifEncoder.FinishEncoder();*/

	return TRUE;
}

LRESULT CMainDlg::OnDestroy(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
{
	// unregister message filtering and idle updates
	CMessageLoop* pLoop = _Module.GetMessageLoop();
	ATLASSERT(pLoop != NULL);
	pLoop->RemoveMessageFilter(this);
	pLoop->RemoveIdleHandler(this);

	// if UI is the last thread, no need to wait
	if(_Module.GetLockCount() == 1)
	{
		_Module.m_dwTimeOut = 0L;
		_Module.m_dwPause = 0L;
	}
	_Module.Unlock();

	return 0;
}

LRESULT CMainDlg::OnLButtonDown(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
{
	if (!m_bCaptureWindows)
	{
		POINT pt = { 0 };
		RECT rect = { 0 };
		::GetCursorPos(&pt);
		GetDlgItem(IDC_STATIC_BACKGROUND).GetWindowRect(&rect);
		if (PtInRect(&rect, pt))
		{
			memcpy(&m_pt_org, &pt, sizeof(pt));
			memcpy(&m_pt_now_bak, &m_pt_now, sizeof(m_pt_now));
			::SetCapture(m_hWnd);
			m_hCursor = ::SetCursor(LoadCursor(NULL, IDC_SIZEALL));
			m_bCaptureWindows = true;
		}
	}
	
	return 0;
}

LRESULT CMainDlg::OnLButtonUp(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
{	
	if (m_bCaptureWindows)
	{
		//RECT rect = { 0 };
		//POINT pt = { 0 };
		//if (GetCursorPos(&pt))
		//{
			//m_pt_org.left = m_pt_org.left + (pt.x - m_pt_org.x);
			//m_pt_org.top = m_pt_org.top + (pt.y - m_pt_org.y);
			
		//GetDlgItem(IDC_STATIC_BACKGROUND).GetClientRect(&rect);
			//InvalidateRect(&rect);
			//UpdateWindow();
		//}
		SetCursor(m_hCursor);

		m_bCaptureWindows = false;
	}
	::ReleaseCapture();

	return 0;
}

LRESULT CMainDlg::OnMouseMove(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
{
	if (m_bCaptureWindows)
	{
		POINT pt = { 0 };
		RECT rect = { 0 };
		POINT pt_bak = { 0 };

		if (GetCursorPos(&pt))
		{
			pt_bak.x = m_pt_now_bak.x + (pt.x - m_pt_org.x);
			pt_bak.y = m_pt_now_bak.y + (pt.y - m_pt_org.y);
			
			GetDlgItem(IDC_STATIC_BACKGROUND).GetClientRect(&rect);
			GetDlgItem(IDC_STATIC_BACKGROUND).MapWindowPoints(m_hWnd, &rect);

			if (/*(PtInRect(&rect, pt)) && */(PtInRect(&rect, pt_bak)))
			{
				m_bCaptureWindows = true;
				memcpy(&m_pt_now, &pt_bak, sizeof(pt_bak));
				InvalidateRect(&rect);
				UpdateWindow();
			}
			else
			{
				m_bCaptureWindows = false;
			}
		}
		else
		{
			//m_bCaptureWindows = false;
		}
	}
	return 0;
}

LRESULT CMainDlg::OnCaptureChanged(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM lParam, BOOL& /*bHandled*/)
{
	m_bCaptureWindows = ((HWND)lParam == m_hWnd);
	return 0;
}

LRESULT CMainDlg::OnAppAbout(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
	CAboutDlg dlg;
	dlg.DoModal();
	return 0;
}
void CMainDlg::DrawMarkText(HDC hDC, size_t stIdx = 0)
{	
	float            fontSize = 28.0f;    //�ֺ�  
	int              fontStyle = Gdiplus::FontStyle::FontStyleRegular;   //����Ч�����򡢴��塢б�塢��б�塢�»��ߡ�ǿ����  
	TSTRING tsDrawText = _T(USAGE_TEXT);
	_TCHAR tzFontName[LF_FULLFACESIZE] = _T(USAGE_FONT);

	if (m_fFontSize)
	{
		fontSize = m_fFontSize;
	}
	if (m_fontStyle)
	{
		fontStyle = m_fontStyle;
	}
	if (*m_tzFontName)
	{
		wsprintf(tzFontName, _T("%s\0"), m_tzFontName);
	}
	if (stIdx < m_vMarkText.size())
	{
		tsDrawText = m_vMarkText.at(stIdx).c_str();
	}
	
	COLORREF clrFontColor = RGB(255, 0, 0);
	if (m_clrFontColor != 0)
	{
		clrFontColor = m_clrFontColor;
	}

	Gdiplus::StringFormat strformat;
	Gdiplus::GraphicsPath path;
	Gdiplus::Color  fontColor(255, GetRValue(clrFontColor), GetGValue(clrFontColor), GetBValue(clrFontColor));
	Gdiplus::FontFamily fontFamily(tzFontName);
	Gdiplus::Font       font(&fontFamily, fontSize, fontStyle, Gdiplus::Unit::UnitPixel);
	Gdiplus::SolidBrush solidBrush(fontColor);
	
	//gdi+��ͼ  
	Gdiplus::Graphics graphics(hDC);
	graphics.SetSmoothingMode(Gdiplus::SmoothingModeNone);
	graphics.SetInterpolationMode(Gdiplus::InterpolationModeHighQualityBicubic);
	//graphics.DrawImage(m_pImage, 0, 0, m_pImage->GetWidth(), m_pImage->GetHeight());
	//graph.FillRectangle(&SolidBrush(Color::Green), 10, 10, 25, 25);
	//graphics.FillRectangle(&Gdiplus::SolidBrush(Gdiplus::Color::Red), 100, 50, 30, 30);//ģ�ⰴť  
	switch (m_fstype)
	{
	case FSTYPE_NULL:
	{
		graphics.DrawString(tsDrawText.c_str(), (-1), &font, Gdiplus::PointF(m_pt_now.x, m_pt_now.y), &solidBrush);
	}
	break;
	case FSTYPE_BDBB:
	{
		path.AddString(tsDrawText.c_str(), tsDrawText.length(), &fontFamily, fontStyle, fontSize, Gdiplus::Point(m_pt_now.x, m_pt_now.y), &strformat);
		Gdiplus::Pen pen(Gdiplus::Color(255, 255, 255), 6);
		graphics.DrawPath(&pen, &path);
		Gdiplus::SolidBrush brush(Gdiplus::Color(0, 0, 0));
		graphics.FillPath(&brush, &path);
	}
	break;
	case FSTYPE_BBBD:
	{
		path.AddString(tsDrawText.c_str(), tsDrawText.length(), &fontFamily, fontStyle, fontSize, Gdiplus::Point(m_pt_now.x, m_pt_now.y), &strformat);
		Gdiplus::Pen pen(Gdiplus::Color(0, 0, 0), 6);
		graphics.DrawPath(&pen, &path);
		Gdiplus::SolidBrush brush(Gdiplus::Color(255, 255, 255));
		graphics.FillPath(&brush, &path);
	}
	break;
	case FSTYPE_1:
	{
		path.AddString(tsDrawText.c_str(), tsDrawText.length(), &fontFamily, fontStyle, fontSize, Gdiplus::Point(m_pt_now.x, m_pt_now.y), &strformat);
		Gdiplus::Pen pen(Gdiplus::Color(234, 137, 6), 6);
		graphics.DrawPath(&pen, &path);
		Gdiplus::SolidBrush brush(Gdiplus::Color(128, 0, 255));
		graphics.FillPath(&brush, &path);
	}
	break;
	case FSTYPE_2:
	{
		path.AddString(tsDrawText.c_str(), tsDrawText.length(), &fontFamily, fontStyle, fontSize, Gdiplus::Point(m_pt_now.x, m_pt_now.y), &strformat);
		Gdiplus::Pen pen(Gdiplus::Color(234, 137, 6), 6);
		graphics.DrawPath(&pen, &path);
		Gdiplus::SolidBrush brush(Gdiplus::Color(128, 0, 255));
		graphics.FillPath(&brush, &path);
	}
	break;
	case FSTYPE_3:
	{
		path.AddString(tsDrawText.c_str(), tsDrawText.length(), &fontFamily, fontStyle, fontSize, Gdiplus::Point(m_pt_now.x, m_pt_now.y), &strformat);
		Gdiplus::Pen pen(Gdiplus::Color(234, 137, 6), 6);
		pen.SetLineJoin(Gdiplus::LineJoinRound);
		graphics.DrawPath(&pen, &path);
		Gdiplus::SolidBrush brush(Gdiplus::Color(128, 0, 255));
		graphics.FillPath(&brush, &path);

	}
	break;
	case FSTYPE_4:
	{
		path.AddString(tsDrawText.c_str(), tsDrawText.length(), &fontFamily, fontStyle, fontSize, Gdiplus::Point(m_pt_now.x, m_pt_now.y), &strformat);
		Gdiplus::Pen pen(Gdiplus::Color(0, 0, 160), 5);
		pen.SetLineJoin(Gdiplus::LineJoinRound);
		graphics.DrawPath(&pen, &path);
		Gdiplus::LinearGradientBrush brush(Gdiplus::Rect(10, 10, 30, 60), Gdiplus::Color(132, 200, 251), Gdiplus::Color(0, 0, 160), Gdiplus::LinearGradientModeVertical);
		graphics.FillPath(&brush, &path);
	}
	break;
	case FSTYPE_5:
	{
		path.AddString(tsDrawText.c_str(), tsDrawText.length(), &fontFamily, fontStyle, fontSize, Gdiplus::Point(m_pt_now.x, m_pt_now.y), &strformat);
		Gdiplus::Pen penOut(Gdiplus::Color(32, 117, 81), 12);
		penOut.SetLineJoin(Gdiplus::LineJoinRound);
		graphics.DrawPath(&penOut, &path);
		Gdiplus::Pen pen(Gdiplus::Color(234, 137, 6), 6);
		pen.SetLineJoin(Gdiplus::LineJoinRound);
		graphics.DrawPath(&pen, &path);
		Gdiplus::SolidBrush brush(Gdiplus::Color(128, 0, 255));
		graphics.FillPath(&brush, &path);
	}
	break;
	case FSTYPE_6:
	{
		path.AddString(tsDrawText.c_str(), tsDrawText.length(), &fontFamily, fontStyle, fontSize, Gdiplus::Point(m_pt_now.x, m_pt_now.y), &strformat);
		for (int i = 1; i < 8; ++i)
		{
			Gdiplus::Pen pen(Gdiplus::Color(32, 0, 128, 192), i);
			pen.SetLineJoin(Gdiplus::LineJoinRound);
			graphics.DrawPath(&pen, &path);
		}
		Gdiplus::SolidBrush brush(Gdiplus::Color(255, 255, 255));
		graphics.FillPath(&brush, &path);
	}
	break;
	}
	graphics.ReleaseHDC(hDC);
}
void CMainDlg::DrawMarkTextReality(HDC hDC, size_t stIdx = 0)
{
	RECT rect = { 0 };
	GetDlgItem(IDC_STATIC_BACKGROUND).GetClientRect(&rect);
	GetDlgItem(IDC_STATIC_BACKGROUND).MapWindowPoints(m_hWnd, &rect);

	POINT pt = { m_nScaleValue * (m_pt_now.x - rect.left), m_nScaleValue * (m_pt_now.y - rect.top)};
	float            fontSize = 28.5f;    //�ֺ�  
	int              fontStyle = Gdiplus::FontStyle::FontStyleRegular;   //����Ч�����򡢴��塢б�塢��б�塢�»��ߡ�ǿ����  
	TSTRING tsDrawText = _T(USAGE_TEXT);
	_TCHAR tzFontName[LF_FULLFACESIZE] = _T(USAGE_FONT);
	if (m_fFontSize)
	{
		fontSize = m_fFontSize;
	}
	if (m_fontStyle)
	{
		fontStyle = m_fontStyle;
	}
	if (*m_tzFontName)
	{
		wsprintf(tzFontName, _T("%s\0"), m_tzFontName);
	}
	if (stIdx < m_vMarkText.size())
	{
		tsDrawText = m_vMarkText.at(stIdx).c_str();
	}
	
	COLORREF clrFontColor = RGB(255, 0, 0);
	if (m_clrFontColor != 0)
	{
		clrFontColor = m_clrFontColor;
	}

	Gdiplus::StringFormat strformat;
	Gdiplus::GraphicsPath path;
	Gdiplus::Color  fontColor(255, GetRValue(clrFontColor), GetGValue(clrFontColor), GetBValue(clrFontColor));
	Gdiplus::FontFamily fontFamily(tzFontName);
	Gdiplus::Font       font(&fontFamily, fontSize, fontStyle, Gdiplus::Unit::UnitPixel);
	Gdiplus::SolidBrush solidBrush(fontColor);

	//gdi+��ͼ  
	Gdiplus::Graphics graphics(hDC);
	graphics.SetSmoothingMode(Gdiplus::SmoothingModeNone);
	graphics.SetInterpolationMode(Gdiplus::InterpolationModeHighQualityBicubic);
	//graphics.DrawImage(m_pImage, 0, 0, m_pImage->GetWidth(), m_pImage->GetHeight());
	//graph.FillRectangle(&SolidBrush(Color::Green), 10, 10, 25, 25);
	//graphics.FillRectangle(&Gdiplus::SolidBrush(Gdiplus::Color::Red), 100, 50, 30, 30);//ģ�ⰴť  
	switch (m_fstype)
	{
	case FSTYPE_NULL:
	{
		graphics.DrawString(tsDrawText.c_str(), (-1), &font, Gdiplus::PointF(pt.x, pt.y), &solidBrush);
	}
	break;
	case FSTYPE_BDBB:
	{
		path.AddString(tsDrawText.c_str(), tsDrawText.length(), &fontFamily, fontStyle, fontSize, Gdiplus::Point(pt.x, pt.y), &strformat);
		Gdiplus::Pen pen(Gdiplus::Color(255, 255, 255), 6);
		graphics.DrawPath(&pen, &path);
		Gdiplus::SolidBrush brush(Gdiplus::Color(0, 0, 0));
		graphics.FillPath(&brush, &path);
	}
	break;
	case FSTYPE_BBBD:
	{
		path.AddString(tsDrawText.c_str(), tsDrawText.length(), &fontFamily, fontStyle, fontSize, Gdiplus::Point(pt.x, pt.y), &strformat);
		Gdiplus::Pen pen(Gdiplus::Color(0, 0, 0), 6);
		graphics.DrawPath(&pen, &path);
		Gdiplus::SolidBrush brush(Gdiplus::Color(255, 255, 255));
		graphics.FillPath(&brush, &path);
	}
	break;
	case FSTYPE_1:
	{
		path.AddString(tsDrawText.c_str(), tsDrawText.length(), &fontFamily, fontStyle, fontSize, Gdiplus::Point(pt.x, pt.y), &strformat);
		Gdiplus::Pen pen(Gdiplus::Color(234, 137, 6), 6);
		graphics.DrawPath(&pen, &path);
		Gdiplus::SolidBrush brush(Gdiplus::Color(128, 0, 255));
		graphics.FillPath(&brush, &path);
	}
	break;
	case FSTYPE_2:
	{
		path.AddString(tsDrawText.c_str(), tsDrawText.length(), &fontFamily, fontStyle, fontSize, Gdiplus::Point(pt.x, pt.y), &strformat);
		Gdiplus::Pen pen(Gdiplus::Color(234, 137, 6), 6);
		graphics.DrawPath(&pen, &path);
		Gdiplus::SolidBrush brush(Gdiplus::Color(128, 0, 255));
		graphics.FillPath(&brush, &path);
	}
	break;
	case FSTYPE_3:
	{
		path.AddString(tsDrawText.c_str(), tsDrawText.length(), &fontFamily, fontStyle, fontSize, Gdiplus::Point(pt.x, pt.y), &strformat);
		Gdiplus::Pen pen(Gdiplus::Color(234, 137, 6), 6);
		pen.SetLineJoin(Gdiplus::LineJoinRound);
		graphics.DrawPath(&pen, &path);
		Gdiplus::SolidBrush brush(Gdiplus::Color(128, 0, 255));
		graphics.FillPath(&brush, &path);

	}
	break;
	case FSTYPE_4:
	{
		path.AddString(tsDrawText.c_str(), tsDrawText.length(), &fontFamily, fontStyle, fontSize, Gdiplus::Point(pt.x, pt.y), &strformat);
		Gdiplus::Pen pen(Gdiplus::Color(0, 0, 160), 5);
		pen.SetLineJoin(Gdiplus::LineJoinRound);
		graphics.DrawPath(&pen, &path);
		Gdiplus::LinearGradientBrush brush(Gdiplus::Rect(10, 10, 30, 60), Gdiplus::Color(132, 200, 251), Gdiplus::Color(0, 0, 160), Gdiplus::LinearGradientModeVertical);
		graphics.FillPath(&brush, &path);
	}
	break;
	case FSTYPE_5:
	{
		path.AddString(tsDrawText.c_str(), tsDrawText.length(), &fontFamily, fontStyle, fontSize, Gdiplus::Point(pt.x, pt.y), &strformat);
		Gdiplus::Pen penOut(Gdiplus::Color(32, 117, 81), 12);
		penOut.SetLineJoin(Gdiplus::LineJoinRound);
		graphics.DrawPath(&penOut, &path);
		Gdiplus::Pen pen(Gdiplus::Color(234, 137, 6), 6);
		pen.SetLineJoin(Gdiplus::LineJoinRound);
		graphics.DrawPath(&pen, &path);
		Gdiplus::SolidBrush brush(Gdiplus::Color(128, 0, 255));
		graphics.FillPath(&brush, &path);
	}
	break;
	case FSTYPE_6:
	{
		path.AddString(tsDrawText.c_str(), tsDrawText.length(), &fontFamily, fontStyle, fontSize, Gdiplus::Point(pt.x, pt.y), &strformat);
		for (int i = 1; i < 8; ++i)
		{
			Gdiplus::Pen pen(Gdiplus::Color(32, 0, 128, 192), i);
			pen.SetLineJoin(Gdiplus::LineJoinRound);
			graphics.DrawPath(&pen, &path);
		}
		Gdiplus::SolidBrush brush(Gdiplus::Color(255, 255, 255));
		graphics.FillPath(&brush, &path);
	}
	break;
	}

	graphics.ReleaseHDC(m_mb_now.hMDC);	
}
LRESULT CMainDlg::OnOK(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
	// TODO: Add validation code 
	
	//CloseDialog(wID);
	return 0;
}

LRESULT CMainDlg::OnCancel(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
	CloseDialog(wID);
	return 0;
}

void CMainDlg::CloseDialog(int nVal)
{
	DestroyWindow();
	::PostQuitMessage(nVal);
}
