// MainDlg.h : interface of the CMainDlg class
//
/////////////////////////////////////////////////////////////////////////////

#pragma once

#define USAGE_FONT "����"
//#define USAGE_TEXT "����ר�������Ӻ�׺ - ʹ��˵��\r\n1.����GIF����ͼƬ:��קGIFͼƬ������.\r\n2.��ˮӡ�б��ļ�:������ļ���ť��ѡ���ļ�����.\r\n3.����GIF�ļ�:�����ļ�����Ŀ¼out\\ˮӡ����.gif"
#define USAGE_TEXT "������ˮӡ����GIF���� v1.0(xingyun86) - ʹ��˵��\r\n1.����GIF����ͼƬ:��קGIFͼƬ������.\r\n2.��ˮӡ�б��ļ�:������ļ���ť��ѡ���ļ�����.\r\n3.����GIF�ļ�:�����ļ�����Ŀ¼out\\ˮӡ����.gif"

//#using "gif.dll"
#include "GifEncoderHeader.h"

//using namespace Gif::Components;

typedef struct tagMemoryBuffer {
	HDC hMDC;
	HBITMAP hMBitmap;
	HBITMAP hBBitmap;
}MEMORYBUFFER, *PMEMORYBUFFER;
typedef enum FONTSTOKETYPE {
	FSTYPE_NULL = 0,
	FSTYPE_BDBB,
	FSTYPE_BBBD,
	FSTYPE_1,
	FSTYPE_2,
	FSTYPE_3,
	FSTYPE_4,
	FSTYPE_5,
	FSTYPE_6,
	FSTYPE_7,
};
__inline static BOOL SelectSaveFile(_TCHAR(&tFileName)[MAX_PATH], const _TCHAR * ptFilter = _T("Execute Files (*.EXE)\0*.EXE\0All Files (*.*)\0*.*\0\0"), HWND hWndOwner = NULL, DWORD dwFlags = OFN_EXPLORER | OFN_ENABLEHOOK | OFN_HIDEREADONLY | OFN_NOCHANGEDIR | OFN_PATHMUSTEXIST, LPOFNHOOKPROC lpofnHookProc = NULL)
{
	BOOL bResult = FALSE;
	OPENFILENAME ofn = { 0 };
	ofn.lStructSize = sizeof(OPENFILENAME);
	ofn.lpstrFilter = ptFilter;
	ofn.lpstrFile = tFileName;
	ofn.hwndOwner = hWndOwner;
	ofn.lpfnHook = lpofnHookProc;
	ofn.nMaxFile = MAX_PATH;
	ofn.Flags = dwFlags;
	bResult = GetSaveFileName(&ofn);
	if (bResult == FALSE)
	{
		//dwError = CommDlgExtendedError();
		//return bResult;
	}
	return bResult;
}
__inline static BOOL SelectOpenFile(_TCHAR(&tFileName)[MAX_PATH], const _TCHAR * ptFilter = _T("Execute Files (*.EXE)\0*.EXE\0All Files (*.*)\0*.*\0\0"), HWND hWndOwner = NULL, DWORD dwFlags = OFN_EXPLORER | OFN_ENABLEHOOK | OFN_HIDEREADONLY | OFN_NOCHANGEDIR | OFN_PATHMUSTEXIST, LPOFNHOOKPROC lpofnHookProc = NULL)
{
	BOOL bResult = FALSE;
	OPENFILENAME ofn = { 0 };
	ofn.lStructSize = sizeof(OPENFILENAME);
	ofn.lpstrFilter = ptFilter;
	ofn.lpstrFile = tFileName;
	ofn.hwndOwner = hWndOwner;
	ofn.lpfnHook = lpofnHookProc;
	ofn.nMaxFile = MAX_PATH;
	ofn.Flags = dwFlags;
	bResult = GetOpenFileName(&ofn);
	if (bResult == FALSE)
	{
		//dwError = CommDlgExtendedError();
		//return bResult;
	}
	return bResult;
}
__inline static BOOL EnumFontFamily(CComboBox * pComboBox)
{
	BOOL bResult = FALSE;
	Gdiplus::InstalledFontCollection installedFonts;
	INT nFamilyCount = installedFonts.GetFamilyCount();
	if (pComboBox && nFamilyCount > 0)
	{
		Gdiplus::FontFamily * pFontFamily = new Gdiplus::FontFamily[nFamilyCount];
		if (pFontFamily)
		{
			INT nSelIdx = 0;
			INT nNumFound = 0;
			installedFonts.GetFamilies(nFamilyCount, pFontFamily, &nNumFound);
			_TCHAR tzFontName[LF_FULLFACESIZE] = { 0 };
			for (int i = 0; i < nNumFound; ++i)
			{
				memset(tzFontName, 0, sizeof(tzFontName));
				if (Gdiplus::Ok == pFontFamily[i].GetFamilyName(tzFontName))
				{
					pComboBox->InsertString(pComboBox->GetCount(), tzFontName);
					if (!lstrcmpi(_T(USAGE_FONT), tzFontName))
					{
						nSelIdx = i;
					}
				}
			}
			
			pComboBox->SetCurSel(nSelIdx);

			bResult = TRUE;
		}
	}
	return bResult;
}

__inline static void CleanMemoryBuffer(MEMORYBUFFER & mb)
{
	::DeleteObject(mb.hBBitmap);
	::DeleteObject(mb.hMBitmap);
	::DeleteDC(mb.hMDC);
}

__inline static void InitMemoryBuffer(HWND hWnd, MEMORYBUFFER & mb)
{
	//������������  
	RECT rect = { 0 };
	PVOID pvBits = NULL;
	int nBytesPerLine = 0;
	BITMAPINFOHEADER stBmpInfoHeader = { 0 };

	CleanMemoryBuffer(mb);

	::GetClientRect(hWnd, &rect);

	nBytesPerLine = (((rect.right - rect.left) * 32 + 31) & (~31)) >> 3;
	stBmpInfoHeader.biSize = sizeof(BITMAPINFOHEADER);
	stBmpInfoHeader.biWidth = (rect.right - rect.left);
	stBmpInfoHeader.biHeight = (rect.bottom - rect.top);
	stBmpInfoHeader.biPlanes = 1;
	stBmpInfoHeader.biBitCount = 32;
	stBmpInfoHeader.biCompression = BI_RGB;
	stBmpInfoHeader.biClrUsed = 0;
	stBmpInfoHeader.biSizeImage = nBytesPerLine * (rect.bottom - rect.top);

	mb.hMDC = ::CreateCompatibleDC(::GetDC(hWnd));
	mb.hMBitmap = ::CreateCompatibleBitmap(::GetDC(hWnd), rect.right - rect.left, rect.bottom - rect.top);// ::CreateDIBSection(mb.hMDC, (PBITMAPINFO)&stBmpInfoHeader, DIB_RGB_COLORS, &pvBits, NULL, 0);
	mb.hBBitmap = (HBITMAP)::SelectObject(mb.hMDC, mb.hMBitmap);
}
__inline static void InitTransparentMemoryBuffer(HWND hWnd, MEMORYBUFFER & mb)
{
	//������������  
	RECT rect = { 0 };
	int nBytesPerLine = 0;
	BITMAPINFOHEADER stBmpInfoHeader = { 0 };

	::GetClientRect(hWnd, &rect);

	nBytesPerLine = (((rect.right - rect.left) * 32 + 31) & (~31)) >> 3;
	stBmpInfoHeader.biSize = sizeof(BITMAPINFOHEADER);
	stBmpInfoHeader.biWidth = (rect.right - rect.left);
	stBmpInfoHeader.biHeight = (rect.bottom - rect.top);
	stBmpInfoHeader.biPlanes = 1;
	stBmpInfoHeader.biBitCount = 32;
	stBmpInfoHeader.biCompression = BI_RGB;
	stBmpInfoHeader.biClrUsed = 0;
	stBmpInfoHeader.biSizeImage = nBytesPerLine * (rect.bottom - rect.top);

	mb.hMDC = ::CreateCompatibleDC(NULL);
	mb.hMBitmap = ::CreateDIBSection(NULL, (PBITMAPINFO)&stBmpInfoHeader, NULL, NULL, NULL, 0);
	mb.hBBitmap = (HBITMAP)::SelectObject(mb.hMDC, mb.hMBitmap);
}
__inline static void InitTransparentMemoryBuffer(SIZE sz, MEMORYBUFFER & mb)
{
	//������������  
	RECT rect = { 0 };
	int nBytesPerLine = 0;
	BITMAPINFOHEADER stBmpInfoHeader = { 0 };

	nBytesPerLine = ((sz.cx * 32 + 31) & (~31)) >> 3;
	stBmpInfoHeader.biSize = sizeof(BITMAPINFOHEADER);
	stBmpInfoHeader.biWidth = sz.cx;
	stBmpInfoHeader.biHeight = sz.cy;
	stBmpInfoHeader.biPlanes = 1;
	stBmpInfoHeader.biBitCount = 32;
	stBmpInfoHeader.biCompression = BI_RGB;
	stBmpInfoHeader.biClrUsed = 0;
	stBmpInfoHeader.biSizeImage = nBytesPerLine * sz.cy;

	mb.hMDC = ::CreateCompatibleDC(NULL);
	mb.hMBitmap = ::CreateDIBSection(NULL, (PBITMAPINFO)&stBmpInfoHeader, NULL, NULL, NULL, 0);
	mb.hBBitmap = (HBITMAP)::SelectObject(mb.hMDC, mb.hMBitmap);
}
class CMainDlg : public CAxDialogImpl<CMainDlg>, public CUpdateUI<CMainDlg>,
		public CMessageFilter, public CIdleHandler
{
public:
	enum { IDD = IDD_MAINDLG };

	virtual BOOL PreTranslateMessage(MSG* pMsg);
	virtual BOOL OnIdle();

	BEGIN_UPDATE_UI_MAP(CMainDlg)
	END_UPDATE_UI_MAP()

	BEGIN_MSG_MAP(CMainDlg)
		MESSAGE_HANDLER(WM_ERASEBKGND, OnEraseBkGnd)
		MESSAGE_HANDLER(WM_PAINT, OnPaint)
		MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
		MESSAGE_HANDLER(WM_DESTROY, OnDestroy)
		MESSAGE_HANDLER(WM_LBUTTONDOWN, OnLButtonDown)
		MESSAGE_HANDLER(WM_LBUTTONUP, OnLButtonUp)
		MESSAGE_HANDLER(WM_MOUSEMOVE, OnMouseMove)
		MESSAGE_HANDLER(WM_CAPTURECHANGED, OnCaptureChanged)
		MESSAGE_HANDLER(WM_DROPFILES, OnDropFiles)
		MESSAGE_HANDLER(WM_NOTIFY, OnNotify)
		//MESSAGE_HANDLER(WM_CTLCOLORSTATIC, OnCtlColorStatic)
		//MESSAGE_HANDLER(WM_CTLCOLORBTN, OnCtlColorBtn)
		//MESSAGE_HANDLER(WM_CTLCOLOREDIT, OnCtlColorEdit)
		COMMAND_ID_HANDLER(IDC_COMBO_FONTNAME, OnCommandNotify)
		COMMAND_ID_HANDLER(IDC_COMBO_FONTSTYLE, OnCommandNotify)
		COMMAND_ID_HANDLER(IDC_COMBO_FONTSTOKE, OnCommandNotify)
		COMMAND_ID_HANDLER(IDC_CHECK_UNDERLINE, OnCommandNotify)
		COMMAND_ID_HANDLER(IDC_CHECK_STRIKEOUT, OnCommandNotify)
		COMMAND_ID_HANDLER(ID_APP_ABOUT, OnAppAbout)
		COMMAND_ID_HANDLER(IDOK, OnOK)
		COMMAND_ID_HANDLER(IDCANCEL, OnCancel)
		COMMAND_ID_HANDLER(IDC_BUTTON_OPENFILE, OnOpenFile)
		COMMAND_ID_HANDLER(IDC_BUTTON_FONTCOLOR, OnFontColor)
		COMMAND_ID_HANDLER(IDC_BUTTON_APPLYCONFIG, OnApplyConfig)
		COMMAND_ID_HANDLER(IDC_BUTTON_MAKEFILE, OnMakeFile)
	END_MSG_MAP()

// Handler prototypes (uncomment arguments if needed):
//	LRESULT MessageHandler(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
//	LRESULT CommandHandler(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
//	LRESULT NotifyHandler(int /*idCtrl*/, LPNMHDR /*pnmh*/, BOOL& /*bHandled*/)

	LRESULT OnEraseBkGnd(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/);
	LRESULT OnPaint(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/);
	LRESULT OnInitDialog(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/);
	LRESULT OnDestroy(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/);
	LRESULT OnLButtonDown(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/);
	LRESULT OnLButtonUp(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/);
	LRESULT OnMouseMove(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/);
	LRESULT OnCaptureChanged(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/);
	LRESULT OnDropFiles(UINT /*uMsg*/, WPARAM wParam, LPARAM /*lParam*/, BOOL& /*bHandled*/)
	{
		/*{
			HDROP hDrop = (HDROP)wParam;
			_TCHAR tzFilePathName[MAX_PATH] = { 0 };
			UINT nNumOfFiles = DragQueryFile(hDrop, 0xFFFFFFFF, NULL, 0); //�õ��ļ����� 
			for (UINT nIndex = 0; nIndex < nNumOfFiles; ++nIndex)
			{
				//�õ��ļ��� 
				::DragQueryFile(hDrop, nIndex, tzFilePathName, MAX_PATH);
				lstrcpy(m_tzBkImgName, tzFilePathName);
				//���Ʊ���
				RECT rect = { 0 };
				//Gdiplus::Image image(m_vImageList.at(0).c_str());
				Gdiplus::Image image(tzFilePathName);
				Gdiplus::Graphics graphics(m_mb_org.hMDC);
				graphics.SetSmoothingMode(Gdiplus::SmoothingModeNone);
				graphics.SetInterpolationMode(Gdiplus::InterpolationModeHighQualityBicubic);
				GetDlgItem(IDC_STATIC_BACKGROUND).GetClientRect(&rect);
				GetDlgItem(IDC_STATIC_BACKGROUND).MapWindowPoints(m_hWnd, &rect);
				int nWold = rect.right - rect.left;
				int nHold = rect.bottom - rect.top;
				m_szImage.cx = image.GetWidth();
				m_szImage.cy = image.GetHeight();
				m_nScaleValue = 1;
				if (m_szImage.cx > nWold || m_szImage.cy > nHold)
				{
					while (m_nScaleValue++)
					{
						if (m_szImage.cx <= (nWold * m_nScaleValue) && m_szImage.cy <= (nHold * m_nScaleValue))
						{
							break;
						}
					}
				}
				//graphics.DrawImage(&image, Gdiplus::RectF(rect.left, rect.top, m_szImage.cx / m_nScaleValue, m_szImage.cy / m_nScaleValue), 0, 0, image.GetWidth(), image.GetHeight(), Gdiplus::UnitPixel);
				graphics.DrawImage(&image, rect.left, rect.top, m_szImage.cx / m_nScaleValue, m_szImage.cy / m_nScaleValue);
				graphics.ReleaseHDC(m_mb_org.hMDC);

				Invalidate();
				UpdateWindow();

				break;
			}
			
			::DragFinish(hDrop);

			return 0;
		}*/
		HDROP hDrop = (HDROP)wParam;
		_TCHAR tzFilePathName[MAX_PATH] = { 0 };
		UINT nNumOfFiles = DragQueryFile(hDrop, 0xFFFFFFFF, NULL, 0); //�õ��ļ����� 
		for (UINT nIndex = 0; nIndex < nNumOfFiles; ++nIndex)
		{
			//�õ��ļ��� 
			::DragQueryFile(hDrop, nIndex, tzFilePathName, MAX_PATH);
			lstrcpy(m_tzBkImgName, tzFilePathName);

			_TCHAR tzFilePath[MAX_PATH] = { 0 };
			::GetModuleFileName(NULL, tzFilePath, _countof(tzFilePath));
			*(_tcsrchr(tzFilePath, _T('\\')) + sizeof(BYTE)) = _T('\0');
			
			m_vImageList.clear();
			m_vLongTime.clear();
			Gdiplus::Image bkimage(tzFilePathName);
			UINT uDimensionsCount = bkimage.GetFrameDimensionsCount();
			if (uDimensionsCount > 0)
			{
				//Create a GDI + graphics object
				//Gdiplus::Graphics graphics(&dc); 
				//Construct an image
				_TCHAR tzFileName[MAX_PATH] = { 0 };
				GUID guid = { 0 };
				GUID imgguid = { 0 };
				UINT uFrameCount = 0;
				long nDelayTimer = 0;
				UINT uPropertyItemSize = 0;
				Gdiplus::PropertyItem * pPropertyItem = NULL;
				GUID *pGuidList = new GUID[uDimensionsCount];
				Gdiplus::EncoderParameters encoderParameters = { 0 };
				ULONG compression = Gdiplus::EncoderValueCompressionLZW;

				encoderParameters.Count = 1;
				encoderParameters.Parameter[0].Guid = Gdiplus::EncoderQuality;
				encoderParameters.Parameter[0].Type = Gdiplus::EncoderParameterValueTypeLong;
				encoderParameters.Parameter[0].NumberOfValues = 1;
				encoderParameters.Parameter[0].Value = &compression;

				memset(pGuidList, 0, sizeof(GUID) * uDimensionsCount);
				if (pGuidList)
				{
					bkimage.GetFrameDimensionsList(pGuidList, uDimensionsCount);
					memcpy(&guid, &pGuidList[0], sizeof(guid));

					uFrameCount = bkimage.GetFrameCount(&guid);

					// Assume that the image has a property item of type PropertyItemEquipMake.
					// Get the size of that property item.
					uPropertyItemSize = bkimage.GetPropertyItemSize(PropertyTagFrameDelay);
					if (uFrameCount > 0 && uPropertyItemSize > 0)
					{
						// Allocate a buffer to receive the property item.
						pPropertyItem = new Gdiplus::PropertyItem[uPropertyItemSize];
						if (pPropertyItem)
						{
							bkimage.GetPropertyItem(PropertyTagFrameDelay, uPropertyItemSize, pPropertyItem);
						}
						delete pGuidList;
						pGuidList = NULL;

						for (UINT uFrameIndex = 0; uFrameIndex < uFrameCount; uFrameIndex++)
						{
							bkimage.SelectActiveFrame(&guid, uFrameIndex);
							nDelayTimer = ((long*)pPropertyItem->value)[uFrameIndex] * 10;
							m_vLongTime.push_back(nDelayTimer);
							Sleep(nDelayTimer);
							GetEncoderClsid(_T("image/png"), &imgguid);
							memset(tzFileName, 0, sizeof(tzFileName));
							wsprintf(tzFileName, _T("%ssrc\\%ld.png"), tzFilePath, uFrameIndex);
							bkimage.Save(tzFileName, &imgguid, &encoderParameters);
							m_vImageList.push_back(tzFileName);							
						}
						delete pPropertyItem;
						pPropertyItem = NULL;

						//���Ʊ���
						RECT rect = { 0 };
						Gdiplus::Image image(m_vImageList.at(0).c_str());
						//Gdiplus::Image image(L"D:\\DevelopmentEnvironment\\Workspaces\\VisualStudio2015\\Projects\\WaterMarks-20180615\\Win32\\Debug\\src\\0.bmp");
						Gdiplus::Graphics graphics(m_mb_org.hMDC);
						graphics.SetSmoothingMode(Gdiplus::SmoothingModeNone);
						graphics.SetInterpolationMode(Gdiplus::InterpolationModeHighQualityBicubic);
				
						//GetClientRect(&rect);
						//graphics.FillRectangle(&Gdiplus::SolidBrush(Gdiplus::Color::LightPink), rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top);

						GetDlgItem(IDC_STATIC_BACKGROUND).GetClientRect(&rect);
						GetDlgItem(IDC_STATIC_BACKGROUND).MapWindowPoints(m_hWnd, &rect);

						int nWold = rect.right - rect.left;
						int nHold = rect.bottom - rect.top;
						m_szImage.cx = image.GetWidth();
						m_szImage.cy = image.GetHeight();
						m_nScaleValue = 1;
						if (m_szImage.cx > nWold || m_szImage.cy > nHold)
						{
							while (m_nScaleValue++)
							{
								if (m_szImage.cx <= (nWold * m_nScaleValue) && m_szImage.cy <= (nHold * m_nScaleValue))
								{
									break;
								}
							}
						}
						//graphics.DrawImage(&image, Gdiplus::RectF(rect.left, rect.top, m_szImage.cx / m_nScaleValue, m_szImage.cy / m_nScaleValue), 0, 0, image.GetWidth(), image.GetHeight(), Gdiplus::UnitPixel);
						graphics.DrawImage(&image, rect.left, rect.top, m_szImage.cx / m_nScaleValue, m_szImage.cy / m_nScaleValue);
						graphics.ReleaseHDC(m_mb_org.hMDC);

						Invalidate();
						UpdateWindow();
					}
					else
					{
						MessageBox(_T("��ѡ��GIF����ʽ�ļ�����֧�������ļ�"), _T("��ܰ��ʾ"), MB_OK);
					}
				}
				else
				{
					MessageBox(_T("��ѡ��GIF����ʽ�ļ�����֧�������ļ�"), _T("��ܰ��ʾ"), MB_OK);
				}
			}
			else
			{
				MessageBox(_T("��ѡ��GIF����ʽ�ļ�����֧�������ļ�"), _T("��ܰ��ʾ"), MB_OK);
			}
			break;
		}
		
		::DragFinish(hDrop);

		return 0;
	}
	LRESULT OnNotify(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& /*bHandled*/)
	{
		LPNMHDR lpNMHDR = (LPNMHDR)lParam;
		switch (lpNMHDR->idFrom)
		{
		case IDC_SPIN_FONTSIZE:
		{
			LPNMUPDOWN lpNMUPDOWN = (LPNMUPDOWN)lpNMHDR;
			m_fFontSize = lpNMUPDOWN->iPos + lpNMUPDOWN->iDelta;
			Invalidate();
			UpdateWindow();
		}
		break;
		default:
			break;
		}
		return 0;
	}
	LRESULT OnCtlColorStatic(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& /*bHandled*/)
	{
		//�Ѹ����ڱ���ͼƬ�Ȼ�����ť��
		HDC hDC = NULL;
		RECT rect = { 0 };
		//::GetWindowRect((HWND)lParam, &rect);
		//::ScreenToClient(m_hWnd, (LPPOINT)((LPBYTE)&rect));
		//::ScreenToClient(m_hWnd, (LPPOINT)((LPBYTE)&rect + sizeof(POINT)));
		//hDC = ::GetDC(m_hWnd);
		//::BitBlt((HDC)wParam, 0, 0, rect.right - rect.left, rect.bottom - rect.top, hDC, rect.left, rect.top, SRCCOPY);
		//::ReleaseDC(m_hWnd, hDC);

		SetTextColor((HDC)wParam, RGB(255, 255, 255));
		//SetBkColor((HDC)wParam, RGB(0, 0, 0));
		//SetDCBrushColor((HDC)wParam, RGB(255, 255, 0));
		//SetBkMode((HDC)wParam, TRANSPARENT);

		return (LRESULT)GetStockObject(DC_BRUSH);
	}
	LRESULT OnCtlColorBtn(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& /*bHandled*/)
	{
		SetTextColor((HDC)wParam, RGB(255, 0, 0));
		SetBkColor((HDC)wParam, RGB(255, 255, 0));
		SetDCBrushColor((HDC)wParam, GetBkColor((HDC)wParam));
		//SetBkMode((HDC)wParam, TRANSPARENT);
		//nResult = (LRESULT)GetStockObject(NULL_BRUSH);

		return (LRESULT)GetStockObject(DC_BRUSH);
	}
	LRESULT OnCtlColorEdit(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& /*bHandled*/)
	{
		SetTextColor((HDC)wParam, RGB(255, 0, 0));
		SetBkColor((HDC)wParam, RGB(255, 255, 0));
		SetDCBrushColor((HDC)wParam, GetBkColor((HDC)wParam));
		//SetBkMode((HDC)wParam, TRANSPARENT);
		//nResult = (LRESULT)GetStockObject(NULL_BRUSH);

		return (LRESULT)GetStockObject(DC_BRUSH);
	}
	LRESULT OnCommandNotify(WORD wNotifyCode, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		switch (wID)
		{
		case IDC_COMBO_FONTNAME:
		{
			if (wNotifyCode == CBN_SELCHANGE)
			{
				//������������
				((CComboBox)GetDlgItem(IDC_COMBO_FONTNAME)).GetLBText(((CComboBox)GetDlgItem(IDC_COMBO_FONTNAME)).GetCurSel(), m_tzFontName);
				Invalidate();
				UpdateWindow();
			}
		}
		break;
		case IDC_COMBO_FONTSTYLE:
		{
			if (wNotifyCode == CBN_SELCHANGE)
			{
				int tempFontStyle = Gdiplus::FontStyle::FontStyleRegular;
				//�����»���
				if (((CButton)GetDlgItem(IDC_CHECK_UNDERLINE)).GetCheck() == BST_CHECKED)
				{
					tempFontStyle |= Gdiplus::FontStyle::FontStyleUnderline;
				}
				//����ɾ����
				if (((CButton)GetDlgItem(IDC_CHECK_STRIKEOUT)).GetCheck() == BST_CHECKED)
				{
					tempFontStyle |= Gdiplus::FontStyle::FontStyleStrikeout;
				}
				//����������ʽ
				switch (((CComboBox)GetDlgItem(IDC_COMBO_FONTSTYLE)).GetCurSel())
				{
				case 0: {m_fontStyle = Gdiplus::FontStyle::FontStyleRegular | tempFontStyle; } break;
				case 1: {m_fontStyle = Gdiplus::FontStyle::FontStyleBold | tempFontStyle; } break;
				case 2: {m_fontStyle = Gdiplus::FontStyle::FontStyleItalic | tempFontStyle; } break;
				case 3: {m_fontStyle = Gdiplus::FontStyle::FontStyleBoldItalic | tempFontStyle; } break;
				default: {m_fontStyle = Gdiplus::FontStyle::FontStyleRegular | tempFontStyle; }	break;
				}
				Invalidate();
				UpdateWindow();
			}
		}
		break;
		case IDC_COMBO_FONTSTOKE:
		{
			if (wNotifyCode == CBN_SELCHANGE)
			{
				//�����������
				m_fstype = (FONTSTOKETYPE)((CComboBox)GetDlgItem(IDC_COMBO_FONTSTOKE)).GetCurSel();
				Invalidate();
				UpdateWindow();
			}
		}
		break;
		case IDC_CHECK_UNDERLINE:
		{
			if (wNotifyCode == BN_CLICKED)
			{
				//�����»���
				if (((CButton)GetDlgItem(IDC_CHECK_UNDERLINE)).GetCheck() == BST_CHECKED)
				{
					m_fontStyle |= Gdiplus::FontStyle::FontStyleUnderline;
				}
				else
				{
					m_fontStyle &= ~Gdiplus::FontStyle::FontStyleUnderline;
				}
				Invalidate();
				UpdateWindow();
			}
		}
		break;
		case IDC_CHECK_STRIKEOUT:
		{
			if (wNotifyCode == BN_CLICKED)
			{
				//����ɾ����
				if (((CButton)GetDlgItem(IDC_CHECK_STRIKEOUT)).GetCheck() == BST_CHECKED)
				{
					m_fontStyle |= Gdiplus::FontStyle::FontStyleStrikeout;
				}
				else
				{
					m_fontStyle &= ~Gdiplus::FontStyle::FontStyleStrikeout;
				}
				Invalidate();
				UpdateWindow();
			}
		}
		break;
		default:
			break;
		}
		
		return 0;
	}
	LRESULT OnAppAbout(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
	LRESULT OnOK(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
	LRESULT OnCancel(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
	LRESULT OnApplyConfig(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		//���������С
		m_fFontSize = (float)GetDlgItemInt(IDC_EDIT_FONTSIZE);
		//������������
		((CComboBox)GetDlgItem(IDC_COMBO_FONTNAME)).GetLBText(((CComboBox)GetDlgItem(IDC_COMBO_FONTNAME)).GetCurSel(), m_tzFontName);
		
		//�����������
		m_fstype = (FONTSTOKETYPE)((CComboBox)GetDlgItem(IDC_COMBO_FONTSTOKE)).GetCurSel();

		//����������ʽ
		switch (((CComboBox)GetDlgItem(IDC_COMBO_FONTSTYLE)).GetCurSel())
		{
		case 0:	{m_fontStyle = Gdiplus::FontStyle::FontStyleRegular;} break;
		case 1:	{m_fontStyle = Gdiplus::FontStyle::FontStyleBold;} break;
		case 2:	{m_fontStyle = Gdiplus::FontStyle::FontStyleItalic;} break;
		case 3:	{m_fontStyle = Gdiplus::FontStyle::FontStyleBoldItalic;} break;
		default: {m_fontStyle = Gdiplus::FontStyle::FontStyleRegular;}	break;
		}
		//�����»���
		if(((CButton)GetDlgItem(IDC_CHECK_UNDERLINE)).GetCheck() == BST_CHECKED)
		{
			m_fontStyle |= Gdiplus::FontStyle::FontStyleUnderline;
		}
		else
		{
			m_fontStyle &= ~Gdiplus::FontStyle::FontStyleUnderline;
		}
		if (((CButton)GetDlgItem(IDC_CHECK_STRIKEOUT)).GetCheck() == BST_CHECKED)
		{
			m_fontStyle |= Gdiplus::FontStyle::FontStyleStrikeout; 
		} 
		else
		{
			m_fontStyle &= ~Gdiplus::FontStyle::FontStyleStrikeout;
		}

		Invalidate();
		UpdateWindow();

		return 0;
	}
	LRESULT OnOpenFile(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		USES_CONVERSION;
		memset(m_tzFileName, 0, sizeof(m_tzFileName));
		SelectOpenFile(m_tzFileName, _T("Txt Files (*.txt)\0*.txt\0All Files (*.*)\0*.*\0\0"), m_hWnd);
		GetDlgItem(IDC_EDIT_OPENFILE).SetWindowText(m_tzFileName);
		{
			m_vMarkText.clear();
			FILE * pFile = _tfopen(m_tzFileName, _T("rb"));
			if (pFile)
			{
				long nIndex = 0;
				CHAR tLineData[MAX_PATH] = ("");
				while (fgets(tLineData, MAX_PATH, pFile))
				{
					if (*tLineData && (nIndex = strlen(tLineData) - sizeof(char)) >= 0)
					{
						while (*(tLineData + nIndex) == '\r' || *(tLineData + nIndex) == '\n')
						{
							*(tLineData + nIndex--) = '\0';
						}
						if (*tLineData)
						{
							m_vMarkText.push_back(A2W(tLineData));
						}
					}					
					memset(tLineData, 0, sizeof(tLineData));
				}
				fclose(pFile);
				pFile = 0;

				Invalidate();
				UpdateWindow();
			}
		}
		return 0;
	}
	LRESULT OnFontColor(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		//memset(&m_tzFontName, 0, sizeof(m_tzFontName));
		//������ɫ�Ի������
		CColorDialog dlg;
		//�޸���ɫ�Ի����������
		dlg.m_cc.Flags |= CC_RGBINIT;
		//����ģ̬����ɫ�Ի���
		if (IDOK == dlg.DoModal())
		{
			//��ѡ������ɫ����ı� "��ɫ"
			m_clrFontColor = dlg.GetColor();
			Invalidate();
			UpdateWindow();
		}
		return 0;
	}
	LRESULT OnFontName(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		memset(m_tzFontName, 0, sizeof(m_tzFontName));
		//��������Ի������
		CFontDialog dlg;
		//�޸�����Ի����������
		dlg.m_cf.Flags |= CF_USESTYLE;
		//����ģ̬������Ի���
		if (IDOK == dlg.DoModal())
		{
			lstrcpy(m_tzFontName, dlg.m_cf.lpLogFont->lfFaceName);
		}
		return 0;
	}
	void RemoveFolder(const char * pBasePath)
	{
		char czCmd[MAX_PATH * sizeof(LONG)] = ("RMDIR /S /Q \"");
		lstrcpynA(czCmd + lstrlenA(czCmd), pBasePath, lstrlenA(pBasePath) - (!(bool)(*(pBasePath + lstrlenA(pBasePath) - sizeof(CHAR)) != ('\\'))) + sizeof(CHAR));
		lstrcpyA(czCmd + lstrlenA(czCmd), "\"");
		//system(czCmd);
		_pclose(_popen(czCmd, "wb"));
	}
	LRESULT OnMakeFile(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		USES_CONVERSION;
		_TCHAR tzSaveFileName[MAX_PATH] = { 0 };
		memset(tzSaveFileName, 0, sizeof(tzSaveFileName));
		//SelectSaveFile(tzSaveFileName, _T("GIF Files (*.gif)\0*.gif\0\0"), m_hWnd);
		lstrcpy(tzSaveFileName, _T(".\\output.gif"));
		if (!m_vImageList.size())
		{
			MessageBox(_T("��δ���ñ���ͼƬ���������ñ���ͼƬ����ק����ͼƬ����ǰ������漴�ɣ���ִ�����ɶ���"), _T("��ܰ��ʾ"), MB_OK);
			return 0;
		}
		if (!m_vMarkText.size())
		{
			MessageBox(_T("��δ����ˮӡ�ļ�����������ˮӡ�ļ������ļ�->ѡ���趨�õ�ˮӡ�����б��ļ�����ִ�����ɶ���"), _T("��ܰ��ʾ"), MB_OK);
			return 0;
		}
		//FILE * pFileLogger = fopen("out.log", "wb");
		if (*tzSaveFileName)
		{
			char czMessage[1024] = { 0 };
			TSTRING tsResult = _T("��������") + std::to_wstring(m_vMarkText.size()) + _T("��GIF�ļ�!");
			RemoveFolder("tmp\\*.*");
			RemoveFolder("out\\*.*");
			for (size_t n = 0; n < m_vMarkText.size(); n++)
			{
				_TCHAR tFileName[MAX_PATH] = { 0 };
				MEMORYBUFFER mb = { 0 };
				CGifEncoder gifEncoder;

				SIZE sz = { 0,0 };
				Gdiplus::Image sz_image(m_vImageList.begin()->c_str());
				sz.cx = sz_image.GetWidth();
				sz.cy = sz_image.GetHeight();

				//AnimatedGifEncoder ^ age = gcnew AnimatedGifEncoder();
				//System::String ^ ss = gcnew System::String(W2A(tzSaveFileName));
				//age->Start(ss);
				//age->SetDelay(500);
				//-1:no repeat,0:always repeat
				//age->SetRepeat(0);

				gifEncoder.SetFrameSize(sz.cx, sz.cy);
				
				//memset(czMessage, 0, sizeof(czMessage));
				//fprintf(pFileLogger, czMessage, (">>>>>>>>>>>>>n=%ld,size=%ld\r\n"), n, m_vMarkText.size());
				//fflush(pFileLogger);

				//gifEncoder.SetDelayTime(120);
				if (m_vLongTime.size() > 0)
				{
					gifEncoder.SetDelayTime(m_vLongTime.at(0));
				}
				else
				{
					gifEncoder.SetDelayTime(121);
				}
				//memset(czMessage, 0, sizeof(czMessage));
				//fprintf(pFileLogger, czMessage, ("n=%ld,size=%ld<<<<<<<<<<<<<<\r\n"), n, m_vMarkText.size());
				//fflush(pFileLogger);
				memset(tzSaveFileName, 0, sizeof(tzSaveFileName));
				wsprintf(tzSaveFileName, _T(".\\out\\%s.gif"), m_vMarkText.at(n).c_str());
				gifEncoder.StartEncoder(TSTRING(tzSaveFileName));

				for (size_t id = 0; id < m_vImageList.size(); id++)
				{
					//memset(czMessage, 0, sizeof(czMessage));
					//fprintf(pFileLogger, czMessage, (">>>>>>>>>>>>>id=%ld,size=%ld\r\n"), id, m_vImageList.size());
					//fflush(pFileLogger);
					Gdiplus::Image image(m_vImageList.at(id).c_str());
					//memset(czMessage, 0, sizeof(czMessage));
					//fprintf(pFileLogger, czMessage, ("n=%ld,size=%ld<<<<<<<<<<<<<<\r\n"), id, m_vImageList.size());
					//fflush(pFileLogger);
					wsprintf(tFileName, _T("tmp\\%ld.png"), id);
					InitTransparentMemoryBuffer(sz, mb);
					PaintBackgroundReality(mb.hMDC, &image);
					DrawMarkTextReality(mb.hMDC, n);
					SaveHDCToFile(tFileName, mb.hMBitmap);
					CleanMemoryBuffer(mb);

					gifEncoder.AddFrame(TSTRING(tFileName));
					//age->AddFrame(System::Drawing::Image::FromFile(gcnew System::String(W2A(tFileName))));
				}

				gifEncoder.FinishEncoder();

				//age->Finish();
				//tsResult.append(TSTRING(_T("�����ļ�Ϊ")) + TSTRING(tzSaveFileName) + TSTRING(_T("�ɹ�!\r\n")));
			}
			tsResult.append(_T("ȫ���ɹ�!"));
			MessageBox(tsResult.c_str(), _T("�����ʾ"), MB_OK);
		}
		return 0;
	}

	void CloseDialog(int nVal);
private:
	void PaintBackgroundReality(HDC hDC, Gdiplus::Image * pImage);
	void DrawMarkTextReality(HDC hDC, size_t stIdx);
	void PaintBackground(HDC hDC);
	void DrawMarkText(HDC hDC, size_t stIdx);
	void DrawColorButton(HDC hDC);
	int GetEncoderClsid(const WCHAR* format, CLSID* pClsid)
	{
		UINT  num = 0;          // number of image encoders  
		UINT  size = 0;         // size of the image encoder array in bytes  

		Gdiplus::ImageCodecInfo* pImageCodecInfo = NULL;

		Gdiplus::GetImageEncodersSize(&num, &size);
		if (size == 0)
			return -1;  // Failure  

		pImageCodecInfo = (Gdiplus::ImageCodecInfo*)(malloc(size));
		if (pImageCodecInfo == NULL)
			return -1;  // Failure  

		Gdiplus::GetImageEncoders(num, size, pImageCodecInfo);

		for (UINT j = 0; j < num; ++j)
		{
			if (wcscmp(pImageCodecInfo[j].MimeType, format) == 0)
			{
				*pClsid = pImageCodecInfo[j].Clsid;
				free(pImageCodecInfo);
				return j;  // Success  
			}
		}

		free(pImageCodecInfo);
		return -1;  // Failure  
	}
	BOOL SaveHDCToFile(LPCTSTR lpFileName, HBITMAP hBitmap)
	{
		BOOL bRet = FALSE;

		//������ļ�  
		{
			//L"image/bmp" L"image/jpeg"  L"image/gif" L"image/tiff" L"image/png"  
			CLSID pngClsid;
			GetEncoderClsid(_T("image/png"), &pngClsid);//�˴���BMPΪ����������ʽѡ���Ӧ�����ͣ���JPG��L"image/jpeg"   
			Gdiplus::Bitmap *pbmSrc = Gdiplus::Bitmap::FromHBITMAP(hBitmap, NULL);
			// The one EncoderParameter object has an array of values.  
			// In this case, there is only one value (of type ULONG)  
			// in the array. We will let this value vary from 0 to 100.  
			Gdiplus::EncoderParameters encoderParameters = { 0 };
			ULONG compression = Gdiplus::EncoderValueCompressionLZW;
			encoderParameters.Count = 1;
			encoderParameters.Parameter[0].Guid = Gdiplus::EncoderQuality;
			encoderParameters.Parameter[0].Type = Gdiplus::EncoderParameterValueTypeLong;
			encoderParameters.Parameter[0].NumberOfValues = 1;
			encoderParameters.Parameter[0].Value = &compression;
			if (pbmSrc->Save(lpFileName, &pngClsid, &encoderParameters) == Gdiplus::Ok)
			{
				bRet = TRUE;
			}
			delete pbmSrc;
		}

		return bRet;
	}
	
public:
	HCURSOR m_hCursor;
	MEMORYBUFFER m_mb_org;
	MEMORYBUFFER m_mb_now;
		
	POINT m_pt_org;
	POINT m_pt_now;
	POINT m_pt_now_bak;

	bool m_bCaptureWindows;
	bool m_bRecoveryOriginal;

	int m_nScaleValue;
	SIZE m_szImage;
public:
	_TCHAR m_tzBkImgName[MAX_PATH];
	_TCHAR m_tzFileName[MAX_PATH];
	_TCHAR m_tzFontName[LF_FULLFACESIZE];
	COLORREF m_clrFontColor;
	int m_fontStyle;
	float m_fFontSize;
	FONTSTOKETYPE m_fstype;
	std::vector<tstring> m_vMarkText;
	size_t m_nVectorIndex;

	std::vector<tstring> m_vImageList;
	std::vector<long> m_vLongTime;
};
